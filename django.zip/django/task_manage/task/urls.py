from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path('add_task/', views.add_task, name='add_task'),
    path("login/", views.user_login, name="login"),
    path("logout/", views.user_logout, name="logout"),
    path("admin/dashboard/", views.admin_dashboard, name="admin_dashboard"),  # Admin dashboard
    path("user/dashboard/", views.user_dashboard, name="user_dashboard"),  # Standard User dashboard
    path("register/", views.register, name="register"),
    
]