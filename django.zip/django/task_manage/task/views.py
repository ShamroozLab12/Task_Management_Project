from pyexpat.errors import messages
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from .models import Task
from .forms import TaskForm 
from django.shortcuts import redirect
from django.contrib.auth import logout 
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib import messages


def home(request):
   
    return render(request, 'task/home.html')  # Replace 'task/home.html' with your actual template path



@login_required
def user_dashboard(request):
    
    return render(request, 'task/user_dashboard.html')



def user_login(request):
    
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, f'Welcome back, {username}!')
            return redirect('home')  # Redirect to the home page after login
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'task/login.html')

def user_logout(request):
    
    logout(request)  # Log the user out
    return redirect('home')  # Redirect to the home page after logout

def register(request):
    """
    Handles user registration.
    """
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Account created for {username}!')
            return redirect('login')  # Redirect to login page after registration
    else:
        form = UserCreationForm()
    return render(request, 'task/register.html', {'form': form})



@login_required
def admin_dashboard(request):

    return render(request, 'task/admin_dashboard.html')

@login_required
def user_dashboard(request):
   
    return render(request, 'task/user_dashboard.html')



# View to list all tasks
@login_required
def task_list(request):
    tasks = Task.objects.filter(created_by=request.user)  # Show tasks created by the logged-in user
    return render(request, 'task/task_list.html', {'tasks': tasks})

# View to add a new task
@login_required
# views.py

@login_required
def add_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.created_by = request.user  # Assign the task to the logged-in user
            task.save()
            return redirect('task_list')  # Redirect to the task list after adding
        else:
            print(form.errors)  # Print form errors to the console for debugging
    else:
        form = TaskForm()
    return render(request, 'task/addtask.html', {'form': form})

# View to update an existing task
@login_required
def update_task(request, task_id):
    task = get_object_or_404(Task, id=task_id, created_by=request.user)  # Ensure the task belongs to the user
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('task_list')  # Redirect to the task list after updating
    else:
        form = TaskForm(instance=task)
    return render(request, 'task/update_task.html', {'form': form, 'task': task})

# View to delete a task
@login_required
def delete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id, created_by=request.user)  # Ensure the task belongs to the user
    if request.method == 'POST':
        task.delete()
        return redirect('task_list')  # Redirect to the task list after deleting
    return render(request, 'task/confirm_delete.html', {'task': task})

# View to view task details
@login_required
def task_detail(request, task_id):
    task = get_object_or_404(Task, id=task_id, created_by=request.user)  # Ensure the task belongs to the user
    return render(request, 'task/task_detail.html', {'task': task})